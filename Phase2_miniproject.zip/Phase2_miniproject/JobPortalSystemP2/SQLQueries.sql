use Training_19Sep19_Chennai;

create table userJPSp2(
	UserID int primary key,
	userPassword varchar(20),
	userFirstName varchar(25),
	userLastName varchar(25),
	userAge int,
	userGender char,
	userAddress varchar(50),
	userContact varchar(10),
	userType char,
	check(userGender in ('M', 'F', 'T')),
	check(userType in ('U', 'A'))
)
select * from userJPSp2
insert into userJPSp2 values(00001,'Sachin@001','Sachin','Tanwar',22,'M','Jaipur','9660009381','A')
insert into userJPSp2 values(00002,'Sachin@002','Ravi','Teja',23,'M','Jaipu','9660009381','U')
insert into userJPSp2 values(00003,'Sachin@003','Renu','Bhati',24,'F','Jaip','9660009381','U')
insert into userJPSp2 values(00004,'Sachin@004','Raj','Tanwar',25,'M','Jai','9660009381','A')
insert into userJPSp2 values(00005,'Sachin@005','Penu','solanki',26,'F','Ja','9660009381','U')

create table Sachin_46008205.jobJPSp2(
	JobID int primary key,
	jobEmployer varchar(30),
	jobEmployerAddress varchar(25),
	JobEmployerContactNumber varchar(25),
	jobEmployerContactEmailID varchar(100),
	jobSkillsRequired varchar(100),
	jobQualification varchar(50),
	jobLocation varchar(10),
	jobSalary int,
	jobNoOfVacancies int
)
select * from Sachin_46008205.jobJPSp2
insert into Sachin_46008205.jobJPSp2 values(10001,'CAPG','Chennai','9988776655','CAPG@WORKMAIL.COM','.Net, OPPS','M.Tech','Chennai',35000,112)
insert into Sachin_46008205.jobJPSp2 values(10002,'INFY','Mysore','9988776644','INFY@WORKMAIL.COM','Java, C, C++','B.Tech','Delhi',22000,230)
insert into Sachin_46008205.jobJPSp2 values(10003,'TCS','Delhi','9988776633','TCS@WORKMAIL.COM','Salesforce','B.Tech','Chennai',27000,70)
insert into Sachin_46008205.jobJPSp2 values(10004,'IBM','Bangalore','9988776622','IBM@WORKMAIL.COM','BI, Cloud','B.Sc.','Mumbai',42000,42)
insert into Sachin_46008205.jobJPSp2 values(10005,'CDAC','Pune','9988776611','CDAC@WORKMAIL.COM','Java, C, C++','BCA','Pune',21500,65)

create proc sp_Insert_userJPSp2_46008205
@userID int,@UserPassword varchar(20),@UserFirstName varchar(25),@UserLastName varchar(25),@UserAge int,@UserGender char,@UserAddress varchar(50),@UserContact varchar(10),@userType char
as
insert into Sachin_46008205.userJPSp2 values(@userID,@UserPassword,@UserFirstName,@UserLastName,@UserAge,@UserGender,@UserAddress,@UserContact,@userType)

exec sp_Insert_userJPSp2_46008205
@userID = 00006, @UserPassword='Sachin@006',@UserFirstName='Nehal',@UserLastName='Jain',@UserAge=23,@UserGender='F',@UserAddress='Udaipur',@UserContact='9660000022',@userType='A' 

exec sp_Insert_userJPSp2_46008205 00007,'Sachin@007','Shubham','Sharma',24,'M','Ajmer','9660000432','A' 
--------
create proc sp_Insert_jobJPSp2_46008205
@JobID int, @jobEmployer varchar(30), @jobEmployerAddress varchar(25), @JobEmployerContactNumber varchar(25), @jobEmployerContactEmailID varchar(100), @jobSkillsRequired varchar(100),@jobQualification varchar(50), @jobLocation varchar(10),@jobSalary int,@jobNoOfVacancies int
as
insert into Sachin_46008205.jobJPSp2 values(@JobID,@jobEmployer,@jobEmployerAddress,@JobEmployerContactNumber,@jobEmployerContactEmailID,@jobSkillsRequired,@jobQualification,@jobLocation,@jobSalary,@jobNoOfVacancies)

exec sp_Insert_jobJPSp2_46008205
@JobID=10006,@jobEmployer='Accenture',@jobEmployerAddress='Pondicheery',@JobEmployerContactNumber='9988776611',@jobEmployerContactEmailID='Accenture@WORKMAIL.COM',@jobSkillsRequired='AI, ML',@jobQualification='BTECH',@jobLocation='Delhi',@jobSalary=55000,@jobNoOfVacancies=10

exec sp_Insert_jobJPSp2_46008205 10007,'Hexaware','Chennai','9988775500','Hexaware@WORKMAIL.COM','MS Azzure','BTECH','Mumbai',42500,50

create proc sp_Display_userJPSp2_46008205
as
select * from Sachin_46008205.userJPSp2

exec sp_Display_userJPSp2_46008205

create proc sp_Display_jobJPSp2_46008205
as
select * from Sachin_46008205.jobJPSp2

exec sp_Display_jobJPSp2_46008205

create proc sp_Delete_userJPSp2_46008205
@userID int
as
delete from Sachin_46008205.userJPSp2 where UserID=@userID

exec sp_Delete_userJPSp2_46008205 7

create proc sp_Delete_jobJPSp2_46008205
@jobID int
as
delete from Sachin_46008205.jobJPSp2 where JobID=@jobID

exec sp_Delete_jobJPSp2_46008205 10007

create proc sp_Search_userJPSp2_46008205
	@UserID int 
AS
BEGIN
	select * from Sachin_46008205.userJPSp2 where UserID = @UserID
END

exec sp_Search_userJPSp2_46008205 7

create proc sp_Search_jobJPSp2_46008205 
	@JobID int,
	@jobEmployer varchar(30) output,
	@jobEmployerAddress varchar(25) output,
	@JobEmployerContactNumber varchar(25) output,
	@jobEmployerContactEmailID varchar(100) output,
	@jobSkillsRequired varchar(100) output,
	@jobQualification varchar(50) output,
	@jobLocation varchar(10) output,
	@jobSalary int output,
	@jobNoOfVacancies int output
AS
BEGIN
	select   @userPassword = userPassword ,@userFirstName = userFirstName ,  @userLastName = userLastName ,
	@userAge = userAge , @userGender = userGender ,  @userAddress = userAddress,  @userContact = userContact,
	@userType = userType
	from Sachin_46008205.userJPSp2 where UserID = @UserID
END

select * from Sachin_46008205.userJPSp2


create proc sp_SearchjobJPSp2_46008205 
	@JobID int
AS
BEGIN
	select * from Sachin_46008205.jobJPSp2 where JobID = @JobID
END

exec sp_SearchjobJPSp2_46008205 10001


create proc sp_UpdatejobJPSp2_46008205
	@JobID int,
	@jobEmployer varchar(30),
	@jobEmployerAddress varchar(25),
	@JobEmployerContactNumber varchar(25),
	@jobEmployerContactEmailID varchar(100),
	@jobSkillsRequired varchar(100),
	@jobQualification varchar(50),
	@jobLocation varchar(10),
	@jobSalary int,
	@jobNoOfVacancies int
As
update Sachin_46008205.jobJPSp2
set
jobEmployer=@jobEmployer,jobEmployerAddress=@jobEmployerAddress,JobEmployerContactNumber=@JobEmployerContactNumber,
jobEmployerContactEmailID=@jobEmployerContactEmailID,jobSkillsRequired=@jobSkillsRequired,jobQualification=@jobQualification,jobLocation=@jobLocation
,jobSalary=@jobSalary,jobNoOfVacancies=@jobNoOfVacancies
where JobID=@JobID