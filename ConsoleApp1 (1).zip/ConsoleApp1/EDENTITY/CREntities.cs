﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRENTITY
{
    [Serializable]
    public class CREntities
    {
        public string CId { get; set; }
        public string CTitle { get; set; }
        public string CDesc { get; set; }
        public string CModel { get; set; }
        public string CBrand { get; set; }
        public string RCStatus { get; set; }
        public int PurchaseYear { get; set; }
        public int sellerId { get; set; }
        public int ExpectedPrice { get; set; }
        public DateTime AddedDate { get; set; }
    }
}
