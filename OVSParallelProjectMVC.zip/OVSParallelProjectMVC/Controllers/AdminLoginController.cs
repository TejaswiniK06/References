﻿using OVSParallelProjectMVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace OVSParallelProjectMVC.Controllers
{
    public class AdminLoginController : Controller
    {
        OVSContext entities = new OVSContext();
        // GET: AdminLogin
        
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Login()
        {
            if (Session["AdminId"] != null)
                return RedirectToAction("Index");
            else
                return View();
        }

        [HttpPost]
        public ActionResult Login(FormCollection collection)
        {
            string email = collection["Email"];
            string password = collection["Password"];
            var tempUser = entities.Admins.FirstOrDefault(u => u.Email == email && u.Password == password);
            if (tempUser != null)
            {
                Session["AdminId"] = tempUser.AdminId;
                Session["AdminName"] = tempUser.Name;
                Session["Type"] = "Admin";
                return RedirectToAction("Index");
            }
            else
            {
                TempData["LoginError"] = "Invalid Email Or Password";
                return RedirectToAction("Login");
            }
        }

        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            Session.Abandon();
            return RedirectToAction("Login", "AdminLogin");
        }
    }
}