create database ElectorDB

use ElectorDB

create table Elector(
	ElectorID		int				identity primary key,
	ElectorName		text			not null,			
	"Date"			date			not null,
	Gender			text			not null,
	MobileNo		text			not null,
	Address			 varchar(20)	not null,
	EmailAddress	 varchar(20)	not null,
	AgeProof		varchar(20)	not null,
	AddressProof	varchar(20)	not null)

	create procedure sp_InsertElector(
		@electorname text,
		@date	date,
		@gender	text,
		@mobileno	text,
		@address	 varchar(20),
		@emailaddress	 varchar(20),
		@ageproof	 varchar(20),
		@addressproof	varchar(20)	

					)
as
begin
insert into Elector values(@electorname,@date,@gender,@mobileno,@address,@emailaddress,@ageproof,@addressproof)
end

exec sp_InsertElector 'Neelu','2019-06-30','Female','9876654654','pune','neelu12@gmail.com','BirthCertificate','Passport'

select * from Elector