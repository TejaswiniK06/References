﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using JPortalEntity;
using JPortalException;
using JPortalBL;

namespace JPortalPL
{
    /// <summary>
    /// Interaction logic for Window6.xaml
    /// </summary>
    public partial class Window6 : Window
    {
        public Window6()
        {
            InitializeComponent();
            c3canvasForEditjob.Visibility = Visibility.Hidden;
        }

        private void C2btnlogout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
           
                txtbjid.Text = "";
                c3txtbjemployer.Text = "";
                c3txtbjaddress.Text = "";
                c3txtbjcontact.Text = "";
                c3txtbjemail.Text = "";
                c3txtbjskills.Text = "";
                c3txtbjquali.Text = "";
                c3txtbjlocation.Text = "";
                txtjsalary.Text = "";
                txtjvacancies.Text = "";
           
            
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Window1 window1 = new Window1();
            window1.Show();
            this.Hide();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            //JPEntities job = JPBL.SearchJobBLL(7);
            JPEntities job = JPBL.SearchJobBLL(Int32.Parse(txtjid.Text));
            job.JobID = txtbjid.Text;
            job.Employer=c3txtbjemployer.Text ;
            job.Address= c3txtbjaddress.Text;
            job.ContactNumber= c3txtbjcontact.Text;
            job.ContactEmailID= c3txtbjemail.Text;
            job.SkillsRequired= c3txtbjskills.Text;
            job.Qualification= c3txtbjquali.Text;
            job.Location= c3txtbjlocation.Text;
            job.Salary=long.Parse( txtjsalary.Text);
            job.NoOfVacancies=Int32.Parse( txtjvacancies.Text);
            if (JPBL.UpdateJobDetailsBLL(job))
            {
                MessageBox.Show("Updated successfully");
                Window1 window1 = new Window1();
                window1.Show();
                this.Hide();
            }
            else {
                MessageBox.Show("Not updated");
            }
        }

        private void Btnjedit_Click(object sender, RoutedEventArgs e)
        {

            lbljid.Visibility = Visibility.Hidden;
            txtjid.Visibility = Visibility.Hidden;
            btnjedit.Visibility = Visibility.Hidden;
            JPEntities job = JPBL.SearchJobBLL(Int32.Parse(txtjid.Text));
            if (job != null)
            {
                txtbjid.Text = job.JobID;
                c3txtbjemployer.Text = job.Employer;
                c3txtbjaddress.Text = job.Address;
                c3txtbjcontact.Text = job.ContactNumber;
                c3txtbjemail.Text = job.ContactEmailID;
                c3txtbjskills.Text = job.SkillsRequired;
                c3txtbjquali.Text = job.Qualification;
                c3txtbjlocation.Text = job.Location;
                txtjsalary.Text = job.Salary.ToString();
                txtjvacancies.Text = job.NoOfVacancies.ToString();
            }
            c3canvasForEditjob.Visibility = Visibility.Visible;

        }
    }
}
