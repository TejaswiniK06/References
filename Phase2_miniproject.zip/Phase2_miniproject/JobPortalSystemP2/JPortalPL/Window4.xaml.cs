﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using JPortalEntity;
using JPortalException;
using JPortalBL;

namespace JPortalPL
{
    /// <summary>
    /// Interaction logic for Window4.xaml
    /// </summary>
    public partial class Window4 : Window
    {
        public Window4()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            c3txtbjid.Text = "";
            c3txtbjemployer.Text = "";
            c3txtbjaddress.Text = "";
            c3txtbjcontact.Text = "";
            c3txtbjemail.Text = "";
            c3txtbjskills.Text = "";
            c3txtbjquali.Text = "";
            c3txtbjlocation.Text = "";
            txtjsalary.Text = "";
            txtjvacancies.Text = "";
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Window1 window1 = new Window1();
            window1.Show();
            this.Hide();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            JPEntities job = new JPEntities();
            job.JobID = c3txtbjid.Text;
            job.Employer = c3txtbjemployer.Text;
            job.Address = c3txtbjaddress.Text;
            job.ContactNumber = c3txtbjcontact.Text;
            job.ContactEmailID = c3txtbjemail.Text;
            job.SkillsRequired = c3txtbjskills.Text;
            job.Qualification = c3txtbjquali.Text;
            job.Location = c3txtbjlocation.Text;
            job.Salary =Int32.Parse(txtjsalary.Text);
            job.NoOfVacancies =Int32.Parse(txtjvacancies.Text);
            if (JPBL.AddJobDetailsBLL(job))
            {
                MessageBox.Show("Added successfully");
                Window1 window1 = new Window1();
                window1.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Not added");
            }
        }

        private void C2btnlogout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}
