﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using JPortalEntity;
using JPortalException;
using JPortalBL;

namespace JPortalPL
{
    /// <summary>
    /// Interaction logic for Window5.xaml
    /// </summary>
    public partial class Window5 : Window
    {
        public Window5()
        {
            InitializeComponent();
        }

        private void Btnreset_Click(object sender, RoutedEventArgs e)
        {
            c3txtbuid.Text = "";
            c3txtbupassword.Text = "";
            c3txtbufname.Text = "";
            c3txtbulname.Text = "";
            c3txtbuage.Text = "";
            c3txtbugender.Text = "";
            c3txtbuaddress.Text = "";
            c3txtbucontact.Text = "";
            txtutype.Text = "";

    }

    private void C2btnlogout_Click(object sender, RoutedEventArgs e)
        {

            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void Btngoback_Click(object sender, RoutedEventArgs e)
        {
            Window1 window1 = new Window1();
            window1.Show();
            this.Close();
        }

        private void BtnaddUser_Click(object sender, RoutedEventArgs e)
        {
            UserEntities user = new UserEntities();
            user.UserID = c3txtbuid.Text;
            user.Password = c3txtbupassword.Text;
            user.FirstName = c3txtbufname.Text;
            user.LastName = c3txtbulname.Text;
            user.Age =Int32.Parse(c3txtbuage.Text);
            user.Gender = c3txtbugender.Text;
            user.Address = c3txtbuaddress.Text;
            user.PhoneNo = c3txtbucontact.Text;
            user.UserType = txtutype.Text;
            if (JPBL.AddUserDetailsBLL(user))
            {
                MessageBox.Show("Added successfully");
                Window1 window1 = new Window1();
                window1.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Not added");
            }
        }
    }
}
