﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace RegisterElectorEntities
{
    [DataContract]
    public class Elector
    {

        [DataMember]
        public int ElectorID { get; set; }

        [DataMember]
        public string ElectorName { get; set; }

        [DataMember]
        public DateTime Date { get; set; }

        [DataMember]
        public  string Gender  { get; set; }


        [DataMember]
        public string MobileNo { get; set; }

       
        [DataMember]
        public string Address { get; set; }

        [DataMember]
        public string EmailAddress { get; set; }

        [DataMember]
        public string AgeProof { get; set; }


        [DataMember]
        public string AddressProof { get; set; }


    }
}
