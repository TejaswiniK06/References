﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using JPortalEntity;
using JPortalException;
using JPortalBL;

namespace JPortalPL
{
    /// <summary>
    /// Interaction logic for Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        public Window2()
        {
            InitializeComponent();
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            c3txtbuid.Text = "";
            c3txtbupassword.Text = "";
            c3txtbufname.Text = "";
            c3txtbulname.Text = "";
            c3txtbuage.Text = "";
            c3txtbugender.Text = "";
            c3txtbuaddress.Text = "";
            c3txtbuphone.Text = "";
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            MainWindow window = new MainWindow();
            window.Show();
            this.Close();
        }

       

        private void C3txtbutype_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            try
            {
                UserEntities user = new UserEntities();
                user.UserID = c3txtbuid.Text;
                user.Password = c3txtbupassword.Text;
                user.FirstName = c3txtbufname.Text;
                user.LastName = c3txtbulname.Text;
                user.Age = Convert.ToInt32(c3txtbuage.Text);
                user.Gender = c3txtbugender.Text;
                user.Address = c3txtbuaddress.Text;
                user.PhoneNo = c3txtbuphone.Text;
                user.UserType = "U";
                if (JPBL.AddUserDetailsBLL(user))
                {
                    MessageBox.Show("User Added successful!");
                    MainWindow winObj = new MainWindow();
                    winObj.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Not Added");
                }
            }
            catch (JPException ex)
            {
                MessageBox.Show(ex.Message);
                Button_Click(sender, e);
            }
            catch(Exception exp)
            {
                MessageBox.Show(exp.Message);
                Button_Click(sender, e);
            }
        }
    }
}
