﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using OVSParallelProjectMVC.Models;

namespace OVSParallelProjectMVC.Controllers
{
    public class CustomersController : Controller
    {
        private OVSContext db = new OVSContext();

        public ActionResult Home()
        {
            if (Session.Keys.Count > 0 && Session["Type"].ToString() == "Customer")
            {
        
                return View();

            }
            else
            {
                return RedirectToAction("Login", "Customers");
            }
        }
        // GET: Customers
        public ActionResult Index()
        {
            return View(db.Customers.ToList());
        }

        // GET: Customers/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Customer customer = db.Customers.Find(id);
            if (customer == null)
            {
                return HttpNotFound();
            }
            return View(customer);
        }

        // GET: Customers/Create
        public ActionResult Create()
        {
            ViewBag.CustomerId = db.Customers.Count() + 1;
            return View();
        }

        // POST: Customers/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "CustomerId,CustomerName,Gender,ContactNo,Email,Password,ConfirmPassword,Address,City,State,Pincode")] Customer customer)
        {
            if (ModelState.IsValid)
            {
                db.Customers.Add(customer);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(customer);
        }

        // GET: Customers/Edit/5
        public ActionResult Edit(int? id)
        {
            
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Customer customer = db.Customers.Find(id);
            if (customer == null)
            {
                return HttpNotFound();
            }
            return View(customer);
        }

        // POST: Customers/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "CustomerId,CustomerName,Gender,ContactNo,Email,Password,ConfirmPassword,Address,City,State,Pincode")] Customer customer)
        {
            if (ModelState.IsValid)
            {
                db.Entry(customer).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(customer);
        }

        // GET: Customers/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Customer customer = db.Customers.Find(id);
            if (customer == null)
            {
                return HttpNotFound();
            }
            return View(customer);
        }

        // POST: Customers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Customer customer = db.Customers.Find(id);
            db.Customers.Remove(customer);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(FormCollection collection)
        {
            string email = collection["Email"];
            string password = collection["Password"];
            var tempUser = db.Customers.FirstOrDefault(u => u.Email == email && u.Password == password);
            if (tempUser != null)
            {
                Session["CustomerId"] = tempUser.CustomerId;
                Session["CustomerName"] = tempUser.CustomerName;
                Session["Type"] = "Customer";
                return RedirectToAction("Home");
            }
            else
            {
                TempData["LoginError"] = "Invalid Email Or Password";
                return RedirectToAction("Login");
            }
        }

        public ActionResult SignUp()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult SignUp([Bind(Include = "CustomerId,CustomerName,Gender,ContactNo,Email,Password,ConfirmPassword,Address,City,State,Pincode")] Customer customer)
        {
            if (ModelState.IsValid)
            {
                db.Customers.Add(customer);
                db.SaveChanges();
                return RedirectToAction("Login");
            }

            return View(customer);
        }
        
        public ActionResult BuyVehicle()
        {
            if (Session.Keys.Count > 0 && Session["Type"].ToString() == "Customer")
            {
                var vehicles = db.Vehicles.Include(s => s.Dealer);
                return View(vehicles.ToList());

            }
            else
            {
                return RedirectToAction("Login", "Customers");
            }
            
        }

        public ActionResult Buy(int? vid, int? did)
        {
            if (vid == null || did == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Vehicle vehicle = db.Vehicles.Find(vid);
            Showroom showroom = db.Showrooms.Where(id => id.DealerId == did).FirstOrDefault();
            Sale sales = new Sale();
            sales.Cost = vehicle.Cost;
            sales.CustomerId = int.Parse(Session["CustomerId"].ToString());
            sales.VehicleId = vehicle.VehicleId;
            sales.ShowroomId = showroom.ShowroomId;
            DateTime current = DateTime.Now;
            sales.DeliverDate = current.AddDays(1);
            sales.OrderDate = current;
            sales.SalesId   = db.Sales.Count() +1;
            db.Sales.Add(sales);
            if (db.SaveChanges() > 0)
            {
                return RedirectToAction("Home","Customers");
            }
            else
            {
                return RedirectToAction("Home", "Customers");
            }


        }

        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            Session.Abandon();
            return RedirectToAction("Login", "Customers");
        }

        public ActionResult BillingData()
        {
            var sales = db.Sales.Include(s => s.Customer).Include(s => s.Showroom).Include(s => s.Vehicle);
            return View(sales.ToList());
        }

        [HttpPost]
        public ActionResult Search(FormCollection collection)
        {
            string search = collection["Search"];
            string filter = collection["Filter"];
            if (filter == "VehicleName")
            {
                var vehicles = db.Vehicles.Where(id => id.VehicleName.Contains(search) || id.VehicleModel.Contains(search));
                if (vehicles != null)
                    return View(vehicles.ToList());
                else
                {
                    return RedirectToAction("Home");
                }
            }
            if (filter == "DealerName")
            {
                var vehicles = db.Vehicles.Where(id => id.Dealer.DealerName.Contains(search));
                if (vehicles != null)
                    return View(vehicles.ToList());
                else
                {
                    return RedirectToAction("Home");
                }
            }
            return RedirectToAction("Home");
        }

        

        
    }
}
