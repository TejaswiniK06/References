﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RegisterElectorEntities;
using System.Threading.Tasks;
using RegisterElectorDAL.ServiceRegisterElector;

namespace RegisterElectorDAL
{
    public class ElectorDAL
    {
        public void Add(Elector elector)
        {
            try
            {
                ElectorServiceClient client = new ElectorServiceClient();
                client.Add(elector);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
    }
}
