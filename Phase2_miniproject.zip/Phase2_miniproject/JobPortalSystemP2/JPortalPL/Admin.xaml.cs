﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using JPortalEntity;
using JPortalException;
using JPortalBL;

namespace JPortalPL
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
            List<JPEntities> jlist = new List<JPEntities>();
            jlist = JPBL.ListJobDetailsBLL();
            dgshowjobs.ItemsSource = jlist;
            dgshowjobs.IsReadOnly = true;
            showAlljobs.Visibility = Visibility.Hidden;
            List<UserEntities> ulist = new List<UserEntities>();
            ulist = JPBL.ListUserDetailsBLL();
            dgshowuser.ItemsSource = ulist;
            dgshowuser.IsReadOnly = true;
            showallusers.Visibility = Visibility.Hidden;
        }

        private void ShowAlljobs_Click(object sender, RoutedEventArgs e)
        {
            List<JPEntities> jlist = new List<JPEntities>();
            jlist = JPBL.ListJobDetailsBLL();
            dgshowjobs.ItemsSource = jlist;
            dgshowjobs.IsReadOnly = true;
            showAlljobs.Visibility = Visibility.Hidden;
        }

        private void C2btnlogout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void Btndeletejob_Click(object sender, RoutedEventArgs e)
        {
            if (txtdeletejob.Text != null && txtdeletejob.Text != "")
            {
                if (JPBL.DeleteJobDetailsBLL(txtdeletejob.Text))
                {
                    MessageBox.Show("Job Deleted Successfully!");
                    txtdeletejob.Text = "";
                    List<JPEntities> jlist = new List<JPEntities>();
                    jlist = JPBL.ListJobDetailsBLL();
                    dgshowjobs.ItemsSource = jlist;
                    dgshowjobs.IsReadOnly = true;
                }
                else {
                    MessageBox.Show("Not deleted successfully");
                }
            }
            else {
                MessageBox.Show("Enter valid jobID");
            }
        }

        private void AddJob_Click(object sender, RoutedEventArgs e)
        {
            Window4 window4 = new Window4();
            window4.Show();
            this.Hide();
        }

        private void BtnSearchjob_Click(object sender, RoutedEventArgs e)
        {
            List<JPEntities> jlist = new List<JPEntities>();
            jlist.Add(JPBL.SearchJobBLL(Int32.Parse(txtsearchJob.Text)));
            dgshowjobs.ItemsSource = jlist;
            dgshowjobs.IsReadOnly = true;
            showAlljobs.Visibility = Visibility.Visible;
            txtsearchJob.Text = "";
        }

        private void Showallusers_Click(object sender, RoutedEventArgs e)
        {
            List<UserEntities> ulist = new List<UserEntities>();
            ulist = JPBL.ListUserDetailsBLL();
            dgshowuser.ItemsSource = ulist;
            dgshowuser.IsReadOnly = true;
            showallusers.Visibility = Visibility.Hidden;
        }

        private void Btnsearchuser_Click(object sender, RoutedEventArgs e)
        {
            List<UserEntities> ulist = new List<UserEntities>();
            ulist.Add(JPBL.SearchUserBLL(Int32.Parse(txtsearchuser.Text)));
            dgshowuser.ItemsSource = ulist;
            dgshowuser.IsReadOnly = true;
            showallusers.Visibility = Visibility.Visible;
            txtsearchuser.Text = "";
        }

        private void Btndeleteuser_Click(object sender, RoutedEventArgs e)
        {
            if (txtdeleteuser.Text != null && txtdeleteuser.Text != "")
            {
                if (JPBL.DeleteUserDetailsBLL(txtdeleteuser.Text))
                {
                    MessageBox.Show("User Deleted Successfully!");
                    txtdeleteuser.Text = "";
                    List<UserEntities> ulist = new List<UserEntities>();
                    ulist = JPBL.ListUserDetailsBLL();
                    dgshowuser.ItemsSource = ulist;
                    dgshowuser.IsReadOnly = true;
                }
                else
                {
                    MessageBox.Show("Not deleted successfully");
                }
            }
            else
            {
                MessageBox.Show("Enter valid jobID");
            }
        }

        private void Adduser_Click(object sender, RoutedEventArgs e)
        {
            Window5 window5 = new Window5();
            window5.Show();
            this.Hide();
        }

        private void EditJob_Click(object sender, RoutedEventArgs e)
        {
            Window6 window6 = new Window6();
            window6.Show();
            this.Hide();
        }
    }
}
