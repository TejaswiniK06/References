﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using OVSParallelProjectMVC.Models;

namespace OVSParallelProjectMVC.Controllers
{
    public class ShowroomsController : Controller
    {
        private OVSContext db = new OVSContext();

        // GET: Showrooms
        public ActionResult Index()
        {
            var showrooms = db.Showrooms.Include(s => s.Dealer);
            return View(showrooms.ToList());
        }

        // GET: Showrooms/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Showroom showroom = db.Showrooms.Find(id);
            if (showroom == null)
            {
                return HttpNotFound();
            }
            return View(showroom);
        }

        // GET: Showrooms/Create
        public ActionResult Create()
        {
            ViewBag.DealerId = new SelectList(db.Dealers, "DealerId", "DealerName");
            ViewBag.ShowrroomId = db.Showrooms.Count() + 1;
            return View();
        }

        // POST: Showrooms/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ShowroomId,Name,DealerId,OwnerName,ContactNo,City,State,Pincode")] Showroom showroom)
        {
            if (ModelState.IsValid)
            {
                db.Showrooms.Add(showroom);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.DealerId = new SelectList(db.Dealers, "DealerId", "DealerName", showroom.DealerId);
            return View(showroom);
        }

        // GET: Showrooms/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Showroom showroom = db.Showrooms.Find(id);
            if (showroom == null)
            {
                return HttpNotFound();
            }
            ViewBag.DealerId = new SelectList(db.Dealers, "DealerId", "DealerName", showroom.DealerId);
            return View(showroom);
        }

        // POST: Showrooms/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ShowroomId,Name,DealerId,OwnerName,ContactNo,City,State,Pincode")] Showroom showroom)
        {
            if (ModelState.IsValid)
            {
                db.Entry(showroom).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.DealerId = new SelectList(db.Dealers, "DealerId", "DealerName", showroom.DealerId);
            return View(showroom);
        }

        // GET: Showrooms/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Showroom showroom = db.Showrooms.Find(id);
            if (showroom == null)
            {
                return HttpNotFound();
            }
            return View(showroom);
        }

        // POST: Showrooms/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Showroom showroom = db.Showrooms.Find(id);
            db.Showrooms.Remove(showroom);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        public ActionResult ViewShowroom()
        {
            var showrooms = db.Showrooms.Include(s => s.Dealer);
            return View(showrooms.ToList());
        }
    }
}
