﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using JPortalEntity;
using JPortalException;
using JPortalBL;
using System.IO;
using JPortalPL;

namespace JPortalPL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();            
            canvasForUserC2.Visibility = Visibility.Hidden;
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                UserEntities user = new UserEntities();
                if (c1txtUserIdLogin.Text == "123" && c1txtPasswordLogin.Password == "123")
                {
                    Window1 window1 = new Window1();
                    window1.Show();
                    this.Hide();
                }
                else
                {
                    if (c1txtUserIdLogin.Text != null && c1txtUserIdLogin.Text != "")
                    {
                        user = JPBL.SearchUserBLL(Int32.Parse(c1txtUserIdLogin.Text));
                        if (user.UserID != null)
                        {

                            if (user.Password == c1txtPasswordLogin.Password)
                            {
                                c2lblUserName.Content = "Welcome! " + user.FirstName + " " + user.LastName;
                                List<JPEntities> jlist = new List<JPEntities>();
                                jlist = JPBL.ListJobDetailsBLL();
                                c2dgDisplayAllJobs.ItemsSource = jlist;
                                c2dgDisplayAllJobs.IsReadOnly = true;
                                MessageBox.Show("Successful");
                                canvasForUserC2.Visibility = Visibility.Visible;
                                c2btnViewAllJobs.Visibility = Visibility.Hidden;
                                canvasForLoginC1.Visibility = Visibility.Hidden;
                                c3canvasForSearchJob.Visibility = Visibility.Hidden;
                            }
                            else
                            {
                                MessageBox.Show("Enter valid Password");
                                c1txtPasswordLogin.Password = "";
                            }
                        }
                        else
                        {
                            MessageBox.Show("Enter valid UserID");
                            c1txtUserIdLogin.Text = "";
                            c1txtPasswordLogin.Password = "";
                        }
                    }
                    else
                    {
                        MessageBox.Show("Enter userID");
                        c1txtPasswordLogin.Password = "";
                    }
                }
            }
            catch (JPException ex)
            {
                MessageBox.Show(ex.Message);
                c1txtUserIdLogin.Text = "";
                c1txtPasswordLogin.Password = "";
            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.Message);
                c1txtUserIdLogin.Text = "";
                c1txtPasswordLogin.Password = "";
            }
        }

        private void C2dgDisplayAllJobs_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void C2btnSearchByUser_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                JPEntities job = new JPEntities();
                job = JPBL.SearchJobBLL(Int32.Parse(c2txtSearchByUser.Text));
                c2btnViewAllJobs.Visibility = Visibility.Visible;
                c3txtbjobid.Text = job.JobID;
                c3txtbjobemployer.Text = job.Employer;
                c3txtbjobaddress.Text = job.Address;
                c3txtbjobcontact.Text = job.ContactNumber;
                c3txtbjobemail.Text = job.ContactEmailID;
                c3txtbjoblocation.Text = job.Location;
                c3txtbjobskills.Text = job.SkillsRequired;
                c3txtbjobqualification.Text = job.Qualification;
                c3txtbjobsalary.Text = job.Salary.ToString();
                c3txtbjobvacancies.Text = job.NoOfVacancies.ToString();
                c2dgDisplayAllJobs.Visibility = Visibility.Hidden;
                c3canvasForSearchJob.Visibility = Visibility.Visible;
            }
            catch (JPException ex)
            {
                MessageBox.Show( ex.Message);
            }
            catch (Exception e1)
            {
                MessageBox.Show( e1.Message);
            }
        }

        private void C2btnViewAllJobs_Click(object sender, RoutedEventArgs e)
        {
            c2dgDisplayAllJobs.Visibility = Visibility.Visible;
            List<JPEntities> jlist = new List<JPEntities>();
            jlist = JPBL.ListJobDetailsBLL();
            c2dgDisplayAllJobs.ItemsSource = jlist;
            c2btnViewAllJobs.Visibility = Visibility.Hidden;
        }

        private void C1btnSignUp_Click(object sender, RoutedEventArgs e)
        {
            Window2 windowObj = new Window2();
            windowObj.Show();
            this.Close();
        }

        private void C2btnlogout_Click(object sender, RoutedEventArgs e)
        {
            canvasForUserC2.Visibility = Visibility.Hidden;
            c1txtUserIdLogin.Text = "";
            c1txtPasswordLogin.Password = "";
            canvasForLoginC1.Visibility = Visibility.Visible;
        }
    }
}
