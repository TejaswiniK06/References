﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JPortalException
{
    public class JPException : ApplicationException
    {
        public JPException():base(){ }

        public JPException(string message) : base(message){ }

        public JPException(string message, Exception innerException) : base(message, innerException){ }

    }
}
