﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using RegisterElectorEntities;

namespace ServiceRegisterElector
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "ElectorService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select ElectorService.svc or ElectorService.svc.cs at the Solution Explorer and start debugging.
    public class ElectorService : IElectorService
    {
        

        public Elector Add(Elector elector)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection())
                {
                    connection.ConnectionString = ConfigurationManager.ConnectionStrings["ElectorConnection"].ConnectionString;
                    connection.Open();
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandText = "sp_InsertElector";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Clear();
                        cmd.Parameters.AddWithValue("electorname",elector.ElectorName );
                        cmd.Parameters.AddWithValue("date", elector.Date);
                        cmd.Parameters.AddWithValue("gender", elector.Gender);
                        cmd.Parameters.AddWithValue("mobileno",elector.MobileNo);                                       
                        cmd.Parameters.AddWithValue("address",elector.Address);
                        cmd.Parameters.AddWithValue("emailaddress",elector.EmailAddress);
                        cmd.Parameters.AddWithValue("ageproof", elector.AgeProof);
                        cmd.Parameters.AddWithValue("addressproof", elector.AddressProof);
                        cmd.ExecuteNonQuery();
                        connection.Close();
                        return elector;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new FaultException(ex.Message);
            }

        }
    }
}
