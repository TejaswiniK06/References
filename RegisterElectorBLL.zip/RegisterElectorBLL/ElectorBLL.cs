﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RegisterElectorDAL;
using RegisterElectorEntities;

namespace RegisterElectorBLL
{
    public class ElectorBLL
    {
        public void Add(Elector elector)
        {
            try
            {
                ElectorDAL dal = new ElectorDAL();
                dal.Add(elector);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
