create table Sachin_46008205.UserReg(
UserRegId int identity(1,1) primary key,
FirstName varchar(20),
LastName varchar(20),
EmailId varchar(20),
UPassword varchar(20),
ContactNo varchar(15))

insert into Sachin_46008205.UserReg values('Sachin','Tanwar','st091@gmail.com','str123','9874569874')
insert into Sachin_46008205.UserReg values('Ravi','Solanki','st092@gmail.com','str124','9874569884')
insert into Sachin_46008205.UserReg values('Raj','Bhati','st093@gmail.com','str125','9874569894')
insert into Sachin_46008205.UserReg values('Nehal','Jain','st094@gmail.com','str126','9874569864')
insert into Sachin_46008205.UserReg values('Sneha','Pareek','st095@gmail.com','str127','9874569854')