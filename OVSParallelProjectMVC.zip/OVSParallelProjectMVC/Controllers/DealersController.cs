﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using OVSParallelProjectMVC.Models;

namespace OVSParallelProjectMVC.Controllers
{
    public class DealersController : Controller
    {
        private OVSContext db = new OVSContext();

        // GET: Dealers
        public ActionResult Index()
        {
            return View(db.Dealers.ToList());
        }

        // GET: Dealers/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Dealer dealer = db.Dealers.Find(id);
            if (dealer == null)
            {
                return HttpNotFound();
            }
            return View(dealer);
        }

        // GET: Dealers/Create
        public ActionResult Create()
        {
            ViewBag.DealerId = db.Dealers.Count() + 1;
            return View();
        }

        // POST: Dealers/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "DealerId,DealerName,CompanyName,Email,Password,ConfirmPassword,ContactNo,City,State,Pincode")] Dealer dealer)
        {
            if (ModelState.IsValid)
            {
                db.Dealers.Add(dealer);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            

            return View(dealer);
        }

        // GET: Dealers/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Dealer dealer = db.Dealers.Find(id);
            if (dealer == null)
            {
                return HttpNotFound();
            }
            return View(dealer);
        }

        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "DealerId,DealerName,CompanyName,Email,Password,ConfirmPassword,ContactNo,City,State,Pincode")] Dealer dealer)
        {
            if (ModelState.IsValid)
            {
                db.Entry(dealer).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(dealer);
        }

        // GET: Dealers/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Dealer dealer = db.Dealers.Find(id);
            if (dealer == null)
            {
                return HttpNotFound();
            }
            return View(dealer);
        }

        // POST: Dealers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Dealer dealer = db.Dealers.Find(id);
            db.Dealers.Remove(dealer);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(FormCollection collection)
        {
            string email = collection["Email"];
            string password = collection["Password"];
            var tempUser = db.Dealers.FirstOrDefault(u => u.Email == email && u.Password == password);
            if (tempUser != null)
            {
                Session["DealerId"] = tempUser.DealerId;
                Session["DealerName"] = tempUser.DealerName;
                Session["Type"] = "Dealer";
                return RedirectToAction("Home");
            }
            else
            {
                TempData["LoginError"] = "Invalid Email Or Password";
                return RedirectToAction("Login");
            }
        }

        public ActionResult Home()
        {
            if (Session.Keys.Count > 0 && Session["Type"].ToString() == "Dealer")
            {
                int did = int.Parse(Session["DealerId"].ToString());
                var vehicles = db.Vehicles.Include(s => s.Dealer).Where(id => id.DealerId == did);
                return View(vehicles.ToList());

            }
            else
            {
                return RedirectToAction("Login");
            }
        }

        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            Session.Abandon();
            return RedirectToAction("Login", "Dealers");
        }

        public ActionResult SignUp()
        {
            ViewBag.DealerId = db.Dealers.Count() + 1;
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult SignUp([Bind(Include = "DealerId,DealerName,CompanyName,Address,ContactNo,Email,Password,ConfirmPassword,City,State,Pincode")] Dealer dealer)
        {
            if (ModelState.IsValid)
            {
                db.Dealers.Add(dealer);
                db.SaveChanges();
                return RedirectToAction("Login");
            }

            return View(dealer);
        }

        public ActionResult ViewDealer()
        {
            return View(db.Dealers.ToList());
        }
    }
}
