﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using RegisterElectorBLL;
using RegisterElectorEntities;

namespace RegisterElectorWebApp
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void BtnSave_Click(object sender, EventArgs e)
        {

            Elector el = new Elector();
            try
            {
                ElectorBLL bll = new ElectorBLL();
                    el.ElectorName = txtelectorname.Text;
                    el.Date = Convert.ToDateTime(txtdate.Text);
                    el.Gender = Male.Text;
                    el.MobileNo = txtmobileno.Text;
                    el.Address = txtaddress.Text;
                    el.EmailAddress = txtemailaddress.Text;
                    el.AgeProof = DropDownList1.SelectedValue;
                    el.AddressProof = DropDownList2.SelectedValue;
                bll.Add(el);
                lblStatus.Text = "Elector Succesfully added";

            }
            catch (Exception ex)
            {
                lblStatus.Text = "Failed to add Elector details";
            }
        }
    }
}