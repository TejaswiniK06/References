﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text.RegularExpressions;
using JPortalEntity;
using JPortalException;
using JPortalDAL;

namespace JPortalBL
{
    public class JPBL
    {

        public static bool ValidateUser(UserEntities user)

        {

            bool validateUser = true;

            try

            {

                if (!Regex.IsMatch(user.UserID, @"[0-9]{5}"))

                {

                    validateUser = false;

                    throw new JPException("Id should be of length 5");

                }

                //if (!Regex.IsMatch(user.Password, @"^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})"))

                //{

                //    validateUser = false;

                //    throw new JPException("Password must contain one upper case alphabet one lower case alphabet one special character and one numeric value atleast with minimum length of 8");

                //}

                if (user.Age < 18)

                {

                    validateUser = false;

                    throw new JPException("Age must be greater than 18");



                }

                if (user.Gender != "M" && user.Gender != "F")

                {

                    validateUser = false;

                    throw new JPException("Gender should be M or F");

                }

                if (user.UserType != "A" && user.UserType != "U")

                {

                    validateUser = false;

                    throw new JPException("UserType should be A or U");

                }

                if (user.UserID == String.Empty || user.Password == String.Empty || user.FirstName == String.Empty || user.LastName == String.Empty || user.Age.ToString() == String.Empty || user.Gender == String.Empty || user.Address == String.Empty || user.PhoneNo == String.Empty || user.UserType == String.Empty)

                {

                    validateUser = false;

                    throw new JPException("ALL FIELDS ARE MANDATORY");

                }



            }

            catch (JPException ex)

            {

                throw ex;

            }

            catch (Exception ex)

            {

                throw ex;

            }

            return validateUser;

        }



        public static bool ValidateJob(JPEntities job)

        {

            bool validateJob = true;

            try

            {

                if (!Regex.IsMatch(job.JobID, @"[0-9]{5}"))

                {

                    validateJob = false;

                    throw new JPException("Id should be of length 5");

                }

                if (!Regex.IsMatch(job.ContactNumber, @"[6-9][0-9]{9}"))

                {

                    validateJob = false;

                    throw new JPException("Contact number must be of ten digits");

                }

                //if (!Regex.IsMatch(job.ContactEmailID, @"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$"))

                //{

                //    validateJob = false;

                //    throw new JPException("Input must be of Email type");

                //}

                if (job.Salary < 0)

                {

                    validateJob = false;

                    throw new JPException("Salary must be positive");



                }

                if (job.JobID == String.Empty || job.Employer == String.Empty || job.Address == String.Empty || job.ContactNumber == String.Empty || job.ContactEmailID == String.Empty || job.SkillsRequired == String.Empty || job.Qualification == String.Empty || job.Location == String.Empty || job.Salary.ToString() == String.Empty || job.NoOfVacancies.ToString() == String.Empty)

                {

                    validateJob = false;

                    throw new JPException("ALL FIELDS ARE MANDATORY");

                }



            }

            catch (JPException ex)

            {

                throw ex;

            }

            catch (Exception ex)

            {

                throw ex;

            }

            return validateJob;

        }



        public static bool AddUserDetailsBLL(UserEntities user)

        {

            bool isUserAdded = false;

            try

            {

                if (ValidateUser(user))

                {

                    isUserAdded = JPDAL.AddUserDetails(user);

                }

            }

            catch (JPException ex)

            {

                throw ex;

            }
            catch (Exception e)
            {
                throw e;
            }

            return isUserAdded;

        }



        public static bool AddJobDetailsBLL(JPEntities job)

        {

            bool isJobAdded = false;

            try

            {

                if (ValidateJob(job))

                {

                    isJobAdded = JPDAL.AddJobDetailsDAL(job);

                }

            }

            catch (JPException ex)

            {

                throw ex;

            }
            catch (Exception e)
            {
                throw e;
            }

            return isJobAdded;

        }

        public static List<UserEntities> ListUserDetailsBLL()

        {

            return JPDAL.ListAllUserDetailsDAL();

        }



        public static List<JPEntities> ListJobDetailsBLL()

        {

            return JPDAL.ListAllJobDetailsDAL();

        }

        public static bool DeleteUserDetailsBLL(string uID)

        {

            bool isUserDeleted = false;

            try

            {

                isUserDeleted = JPDAL.DeleteUserDetailsDAL(uID);

            }

            catch (JPException ex)

            {

                throw ex;

            }
            catch (Exception e)
            {
                throw e;
            }

            return isUserDeleted;

        }

        public static bool DeleteJobDetailsBLL(string jID)

        {

            bool isJobDeleted = false;

            try

            {

                isJobDeleted = JPDAL.DeleteJobDetailsDAL(jID);

            }

            catch (JPException ex)

            {

                throw ex;

            }
            catch (Exception e)
            {
                throw e;
            }

            return isJobDeleted;

        }

        public static bool UpdateUserDetailsBLL(UserEntities updatedUser)

        {

            bool isUserUpdated = false;

            try

            {

                isUserUpdated = JPDAL.UpdateUserDetailDAL(updatedUser);

            }

            catch (JPException ex)

            {

                throw ex;

            }
            catch (Exception e)
            {
                throw e;
            }

            return isUserUpdated;

        }

        public static bool UpdateJobDetailsBLL(JPEntities updatedJob)

        {

            bool isJobUpdated = false;

            try

            {

                isJobUpdated = JPDAL.UpdateJobDetailDAL(updatedJob);

            }

            catch (JPException ex)

            {

                throw ex;

            }
            catch (Exception e)
            {
                throw e;
            }

            return isJobUpdated;

        }

        public static UserEntities SearchUserBLL(int uID)

        {

            UserEntities user = new UserEntities();

            try

            {

                user = JPDAL.SearchUserDAL(uID);

            }

            catch (JPException ex)

            {

                throw ex;

            }
            catch (Exception e)
            {
                throw e;
            }

            return user;

        }

        public static JPEntities SearchJobBLL(int jID)

        {

            JPEntities job = null;

            try

            {

                job = JPDAL.SearchJobDAL(jID);

            }

            catch (JPException ex)

            {

                throw ex;

            }
            catch (Exception e)
            {
                throw e;
            }

            return job;

        }


    }
}
